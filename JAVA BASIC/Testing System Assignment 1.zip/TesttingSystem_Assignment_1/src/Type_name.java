
public enum Type_name {
ESSAY,MULTIPLE_CHOICE
}
