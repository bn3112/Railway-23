
public class Answer {
byte id;
String content;
Question question;
boolean isCorrect;
}
