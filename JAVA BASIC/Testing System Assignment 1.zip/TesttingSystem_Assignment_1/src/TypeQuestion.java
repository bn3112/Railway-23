
public class TypeQuestion {
byte id;
Type_name type_name;
}
