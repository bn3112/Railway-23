
public class Department {
byte id;
String name;
}
