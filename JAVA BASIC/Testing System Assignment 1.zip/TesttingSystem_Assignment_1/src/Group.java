import java.util.Date;

public class Group {
byte id;
String name;
Account creator;
Date createDate;
}
