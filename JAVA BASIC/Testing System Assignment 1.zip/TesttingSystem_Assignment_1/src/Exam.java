import java.util.Date;
public class Exam {
byte id;
String code;
String title;
CategoryQuestion category;
byte duration;
Account creator;
Date createDate;
Question[] questions;
}
