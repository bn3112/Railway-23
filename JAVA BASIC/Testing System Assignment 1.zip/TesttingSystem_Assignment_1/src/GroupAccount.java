import java.util.Date;

public class GroupAccount {
Group group;
Account[] accounts;
Date joinDate;
}
