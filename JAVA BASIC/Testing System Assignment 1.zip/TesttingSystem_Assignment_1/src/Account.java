import java.util.Date;
public class Account {
int id;
String email;
String userName;
String fullName;
Department department;
Position position;
Date createDate;
// Group[] group;
}
