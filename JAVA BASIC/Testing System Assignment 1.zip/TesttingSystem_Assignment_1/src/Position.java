
public class Position {
byte id;
Position_name name;
}
