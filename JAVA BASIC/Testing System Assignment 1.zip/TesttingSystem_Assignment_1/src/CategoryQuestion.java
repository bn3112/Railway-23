
public class CategoryQuestion {
byte id;
String name;
}
